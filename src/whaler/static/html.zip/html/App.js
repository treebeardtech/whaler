"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const d3 = __importStar(require("d3"));
const react_1 = __importDefault(require("react"));
const Canvas_1 = __importDefault(require("./components/Canvas"));
const GlobalStyle_1 = require("./styles/GlobalStyle");
// const defdata = [
//   {
//     id: '.venv/share/jupyter',
//     value: 7964,
//   },
//   {
//     id: '.venv/asdf',
//     value: 1111,
//   },
//   {
//     id: '.venv/share',
//   },
//   {
//     id: '.venv',
//   },
// ]
// https://github.com/diego3g/electron-typescript-react/issues
exports.App = () => {
    const [data, setData] = react_1.default.useState(null);
    function onChangeFile(event) {
        const file = event.target.files[0];
        console.log(file);
        const reader = new FileReader();
        reader.readAsText(file);
        reader.onload = () => {
            const d = d3.tsvParse(`value\tid\n${reader.result}`);
            setData(d);
        };
        reader.onerror = () => {
            console.log(reader.error);
        };
    }
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement(GlobalStyle_1.GlobalStyle, null),
        data && react_1.default.createElement(Canvas_1.default, { data: data }),
        react_1.default.createElement("div", { style: { width: 800, margin: 'auto' } },
            react_1.default.createElement("p", { style: { fontFamily: 'monaco' } },
                "du -k -a some-dir ",
                '>',
                " disk.tsv",
                react_1.default.createElement("br", null),
                "docker run -it --rm --workdir / --entrypoint /du psutil-example -a -c",
                ' ',
                '>',
                " du.tsv"),
            react_1.default.createElement("input", { id: "myInput", type: "file", onChange: onChangeFile }))));
};
//# sourceMappingURL=App.js.map