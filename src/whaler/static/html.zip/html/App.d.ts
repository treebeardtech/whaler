/// <reference types="react" />
export declare const App: () => JSX.Element;
