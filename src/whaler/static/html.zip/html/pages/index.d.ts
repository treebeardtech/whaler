/// <reference types="react" />
declare const IndexPage: () => JSX.Element;
export default IndexPage;
