"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const styled_components_1 = require("styled-components");
exports.GlobalStyle = styled_components_1.createGlobalStyle `
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  
  body {
    font-family: Arial, Helvetica, sans-serif;
    font-size: 16px;
    color: black;
    background-color: white;
  }
`;
//# sourceMappingURL=GlobalStyle.js.map