import React from 'react';
interface CP {
    data: any;
}
declare const Canvas: React.FC<CP>;
export default Canvas;
